import React, { useState, useEffect } from 'react';
import ControlPanel from './components/ControlPanel';
import VideoGrid from './components/VideoGrid';
import UnlockModal from './components/UnlockModal';
import { getYouTubeID } from './utils';

const App: React.FC = () => {
  const [url, setUrl] = useState<string>('https://youtube.com/shorts/ukCh6ovtOm8?si=FyZ00ThpGjVpI2e1');
  const [videoId, setVideoId] = useState<string | null>(null);
  const [isShort, setIsShort] = useState<boolean>(false);
  
  // Pro Feature State
  const [isPro, setIsPro] = useState<boolean>(false);
  const [showUnlockModal, setShowUnlockModal] = useState<boolean>(false);
  
  // Free users limited to 10, Pro users default to 10 (can go up to 40)
  const [screenCount, setScreenCount] = useState<number>(10);
  
  // Free users limited to 2 min, Pro users 1 min
  const [reloadTime, setReloadTime] = useState<number>(2);
  
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [totalViews, setTotalViews] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(true);
  
  const [refreshKey, setRefreshKey] = useState<number>(0);

  // Check for existing license on startup
  useEffect(() => {
    const savedKey = localStorage.getItem('multiview_pro_key');
    if (savedKey) {
      // In a real app, you might validate this key with the server again on startup
      // to ensure it hasn't been revoked.
      setIsPro(true);
      setScreenCount(20); // Restore pro defaults
      setReloadTime(1);
    }
  }, []);

  // Open the new Unlock Modal
  const handleOpenUnlock = () => {
    setShowUnlockModal(true);
  };

  // Called when valid key is entered in Modal
  const handleUnlockSuccess = () => {
    setIsPro(true);
    // Optionally upgrade their settings immediately to show power
    setScreenCount(20); 
    setReloadTime(1);   
  };

  const handleSubmit = () => {
    const { id, error } = getYouTubeID(url);
    if (id) {
      setVideoId(id);
      // Detect if URL is likely a Short to optimize grid layout
      setIsShort(url.includes('/shorts/'));
      setIsPlaying(true);
      setRefreshKey(prev => prev + 1); 
      setTotalViews(screenCount);
    } else {
      alert(error || "Invalid YouTube URL");
      setIsPlaying(false);
    }
  };

  const handleReset = () => {
    setVideoId(null);
    setIsPlaying(false);
    setUrl('');
    // Reset defaults based on tier (Basic starts at 10 now)
    setScreenCount(10);
    setReloadTime(isPro ? 1 : 2);
    setTotalViews(0);
    setIsMuted(true);
    setIsShort(false);
  };

  const toggleMute = () => {
    setIsMuted(prev => !prev);
  };

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;

    if (isPlaying && reloadTime > 0) {
      const timeInMs = reloadTime * 60 * 1000;
      
      interval = setInterval(() => {
        setRefreshKey(prev => prev + 1);
        setTotalViews(prev => prev + screenCount);
      }, timeInMs);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isPlaying, reloadTime, screenCount]);

  return (
    <div className="min-h-screen bg-[#f8fafc]">
      {/* Top Decoration Line - Changes color if Pro */}
      <div className={`h-1.5 w-full bg-gradient-to-r ${isPro ? 'from-yellow-400 via-orange-300 to-yellow-500' : 'from-green-300 via-blue-300 to-pink-300'}`}></div>

      <div className="container mx-auto px-4 py-8">
        
        {/* Controls Section */}
        <ControlPanel 
          url={url}
          setUrl={setUrl}
          onSubmit={handleSubmit}
          onReset={handleReset}
          screenCount={screenCount}
          setScreenCount={setScreenCount}
          reloadTime={reloadTime}
          setReloadTime={setReloadTime}
          isPlaying={isPlaying}
          totalViews={totalViews}
          isMuted={isMuted}
          toggleMute={toggleMute}
          isPro={isPro}
          onUnlockPro={handleOpenUnlock}
        />

        {isPlaying && (
           <div className="w-full max-w-4xl mx-auto my-8 border-t border-gray-200"></div>
        )}

        {isPlaying && videoId && (
          <VideoGrid 
            videoId={videoId} 
            count={screenCount} 
            refreshKey={refreshKey}
            isMuted={isMuted}
            isShort={isShort}
            isPro={isPro}
          />
        )}

      </div>

      {/* Unlock Modal */}
      <UnlockModal 
        isOpen={showUnlockModal} 
        onClose={() => setShowUnlockModal(false)}
        onUnlock={handleUnlockSuccess}
      />
    </div>
  );
};

export default App;