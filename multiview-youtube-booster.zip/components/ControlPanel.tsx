import React, { useEffect, useState } from 'react';
import { Minus, Plus, Eye, Volume2, VolumeX, Lock, Crown, Zap } from 'lucide-react';

interface ControlPanelProps {
  url: string;
  setUrl: (url: string) => void;
  onSubmit: () => void;
  onReset: () => void;
  screenCount: number;
  setScreenCount: (count: number) => void;
  reloadTime: number;
  setReloadTime: (time: number) => void;
  isPlaying: boolean;
  totalViews: number;
  isMuted: boolean;
  toggleMute: () => void;
  isPro: boolean;
  onUnlockPro: () => void;
}

const ControlPanel: React.FC<ControlPanelProps> = ({
  url,
  setUrl,
  onSubmit,
  onReset,
  screenCount,
  setScreenCount,
  reloadTime,
  setReloadTime,
  isPlaying,
  totalViews,
  isMuted,
  toggleMute,
  isPro,
  onUnlockPro
}) => {
  
  const [bumpAnimation, setBumpAnimation] = useState(false);

  // Trigger animation whenever totalViews updates
  useEffect(() => {
    if (totalViews > 0) {
      setBumpAnimation(true);
      const timer = setTimeout(() => setBumpAnimation(false), 300);
      return () => clearTimeout(timer);
    }
  }, [totalViews]);

  const handleTimeChange = (delta: number) => {
    const newTime = reloadTime + delta;
    
    // Free User Limit: Cannot go below 2 minutes
    if (!isPro && newTime < 2) {
      onUnlockPro();
      return;
    }
    
    setReloadTime(Math.max(1, newTime));
  };

  const handleScreenChange = (count: number) => {
    // Free User Limit: Cannot select more than 10 screens
    if (!isPro && count > 10) {
      onUnlockPro();
      return;
    }
    setScreenCount(count);
  }

  // Define available screen options
  // Basic gets 10. Pro gets 20, 30, 40.
  const screenOptions = [10, 20, 30, 40]; 

  return (
    <div className={`w-full max-w-4xl mx-auto p-6 flex flex-col items-center gap-6 rounded-3xl transition-all duration-500 
      ${isPro 
        ? 'bg-gradient-to-b from-amber-50 to-white/80 border border-amber-200 shadow-2xl shadow-amber-500/10' 
        : 'bg-white/80 border border-white/60 shadow-xl shadow-blue-900/5 backdrop-blur-sm'
      }`}
    >
      
      {/* Header / Upgrade Call to Action */}
      <div className="w-full flex justify-between items-center mb-2">
        <h1 className="text-2xl font-bold text-gray-800 tracking-tight flex items-center gap-2">
          MultiView 
          <span className={`px-2 py-0.5 rounded-md text-sm uppercase tracking-wider font-black ${isPro ? "bg-amber-100 text-amber-600" : "bg-blue-100 text-blue-600"}`}>
            {isPro ? "PRO" : "Booster"}
          </span>
        </h1>
        
        {!isPro && (
          <button 
            onClick={onUnlockPro}
            className="flex items-center gap-2 bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-500 hover:to-orange-600 text-white font-bold py-2 px-4 rounded-full shadow-lg transition-transform hover:scale-105 animate-pulse"
          >
            <Crown size={18} />
            <span>Unlock PRO</span>
          </button>
        )}

        {isPro && (
          <div className="flex items-center gap-1.5 bg-gradient-to-r from-amber-50 to-orange-50 text-amber-700 px-4 py-1.5 rounded-full text-xs font-bold border border-amber-200 shadow-sm animate-in fade-in slide-in-from-right-4">
            <Crown size={14} className="fill-amber-500 text-amber-600" />
            PREMIUM ACTIVE
          </div>
        )}
      </div>

      {/* URL Input */}
      <div className="w-full relative">
        <input
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="Paste YouTube Link Here..."
          className={`w-full p-4 pl-5 text-gray-700 rounded-2xl border-2 outline-none shadow-sm text-sm md:text-base font-medium placeholder-gray-400 transition-all
            ${isPro 
              ? 'bg-white border-amber-200 focus:border-amber-400 focus:ring-4 focus:ring-amber-400/20' 
              : 'bg-blue-50 border-transparent focus:ring-2 focus:ring-blue-200'
            }`}
        />
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full">
        <button
          onClick={onSubmit}
          className={`font-bold py-3 px-6 rounded-2xl shadow-lg transition-all active:scale-95 flex justify-center items-center gap-2 text-white
            ${isPro 
              ? 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 shadow-amber-200' 
              : 'bg-green-500 hover:bg-green-600 shadow-green-200'
            }`}
        >
          <Zap size={20} className="fill-current" />
          Start Booster
        </button>

        <button
          onClick={toggleMute}
          className="flex items-center justify-center gap-2 bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 font-bold py-3 px-6 rounded-2xl shadow-sm transition-all active:scale-95"
        >
          {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
          {isMuted ? "Unmute All" : "Mute All"}
        </button>

        <button
          onClick={onReset}
          className="bg-red-50 hover:bg-red-100 text-red-600 font-bold py-3 px-6 rounded-2xl shadow-sm transition-all active:scale-95 border border-red-100"
        >
          Reset
        </button>
      </div>

      {/* Screen Selection */}
      <div className="w-full">
        <div className="flex items-center gap-2 mb-3">
          <h2 className="text-lg font-bold text-gray-900">
            Select Screens 
            {!isPro && <span className="text-xs font-normal text-gray-500 ml-2">(Free limit: 10)</span>}
          </h2>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {screenOptions.map((count) => {
            // Determine if this specific button is locked
            const isLocked = !isPro && count > 10;
            const isSelected = screenCount === count;

            return (
              <button
                key={count}
                onClick={() => handleScreenChange(count)}
                className={`
                  relative flex flex-col items-center justify-center p-6 rounded-2xl shadow-sm border-2 transition-all overflow-hidden
                  ${isSelected
                    ? (isPro 
                        ? 'bg-amber-50 border-amber-400 scale-105 shadow-md shadow-amber-100' 
                        : 'bg-blue-50 border-blue-400 scale-105')
                    : 'bg-white border-transparent hover:border-gray-200'
                  }
                `}
              >
                {/* Lock Overlay */}
                {isLocked && (
                  <div className="absolute inset-0 bg-gray-100/80 backdrop-blur-[1px] flex flex-col items-center justify-center z-10 cursor-pointer group">
                    <div className="bg-white p-2 rounded-full shadow-md group-hover:scale-110 transition-transform">
                      <Lock size={20} className="text-gray-400" />
                    </div>
                    <span className="text-[10px] font-bold text-gray-500 mt-1 uppercase">Pro Only</span>
                  </div>
                )}

                <span className={`text-xl md:text-2xl font-bold ${isSelected ? 'text-black' : 'text-gray-600'}`}>
                  {count}
                </span>
                <span className="text-sm font-semibold text-gray-500">screens</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Reload Timer Controls */}
      <div className="w-full">
        <div className="flex items-center gap-2 mb-3">
          <h2 className="text-lg font-bold text-gray-900">
            Auto-Reload Timer
            {!isPro && <span className="text-xs font-normal text-gray-500 ml-2">(Free limit: 2 min)</span>}
          </h2>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <button
            onClick={() => handleTimeChange(1)}
            className="flex items-center justify-center bg-gray-100 hover:bg-gray-200 text-gray-800 h-14 rounded-2xl shadow-sm transition-colors"
          >
            <Plus size={24} strokeWidth={3} />
          </button>
          
          <div className={`flex flex-col items-center justify-center border-2 text-gray-800 font-bold h-14 rounded-2xl shadow-sm relative
             ${isPro ? 'bg-white border-amber-200' : 'bg-white border-gray-100'}`}
          >
             <span className="text-lg">{reloadTime} min</span>
             {!isPro && reloadTime === 2 && (
               <span className="absolute -bottom-3 bg-gray-800 text-white text-[10px] px-2 py-0.5 rounded-full">Min Limit</span>
             )}
          </div>

          <button
             onClick={() => handleTimeChange(-1)}
             className="flex items-center justify-center bg-gray-100 hover:bg-gray-200 text-gray-800 h-14 rounded-2xl shadow-sm transition-colors relative"
          >
            <Minus size={24} strokeWidth={3} />
            {/* Lock indicator if user tries to go below 2 min on free */}
            {!isPro && reloadTime <= 2 && (
               <Lock size={12} className="absolute top-1 right-1 text-gray-400" />
            )}
          </button>
        </div>
      </div>

      {/* Total View Counter */}
      {isPlaying && (
        <div className={`flex items-center justify-center gap-6 px-8 py-4 rounded-2xl shadow-lg border mt-4 animate-fade-in w-full md:w-auto transition-colors duration-500
          ${isPro ? 'bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200' : 'bg-white border-gray-100'}
        `}>
           <div className="flex flex-col items-end">
             <span className={`text-xs font-bold uppercase tracking-wider ${isPro ? 'text-amber-700' : 'text-gray-500'}`}>Total Views</span>
             <span className={`text-4xl font-black leading-none transition-transform duration-300 transform ${isPro ? 'text-amber-600' : 'text-blue-600'} ${bumpAnimation ? 'scale-125' : 'scale-100'}`}>
               {totalViews}
             </span>
           </div>
           
           <Eye className={`${isPro ? "text-amber-500" : "text-blue-500"} ${bumpAnimation ? 'animate-pulse' : ''}`} size={48} />
        </div>
      )}

    </div>
  );
};

export default ControlPanel;