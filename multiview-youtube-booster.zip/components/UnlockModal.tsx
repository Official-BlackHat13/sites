import React, { useState, useEffect } from 'react';
import { X, Crown, Check, AlertCircle, ArrowRight, Loader2, ArrowLeft, Copy, MessageCircle, ShieldCheck, Hash } from 'lucide-react';
import { getDeviceId } from '../utils';

interface UnlockModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUnlock: () => void;
}

const UnlockModal: React.FC<UnlockModalProps> = ({ isOpen, onClose, onUnlock }) => {
  const [key, setKey] = useState('');
  const [error, setError] = useState('');
  const [isValidating, setIsValidating] = useState(false);
  const [orderId, setOrderId] = useState('');
  const [showPayment, setShowPayment] = useState(false);
  const [paymentStep, setPaymentStep] = useState<'pay' | 'confirm'>('pay');

  // --- CONFIGURATION ---
  const UPI_ID = "8103358511@okbizaxis";
  const PAYEE_NAME = "Ajmeriya Fintech";
  const PRICE = "499"; // Set your price in INR
  const WHATSAPP_NUMBER = "918103358511"; 
  // ---------------------

  // Generate a random Order ID when modal opens or payment view is toggled
  useEffect(() => {
    if (showPayment && !orderId) {
      const randomId = 'ORD-' + Math.floor(1000 + Math.random() * 9000);
      setOrderId(randomId);
    }
  }, [showPayment, orderId]);

  // Dynamic UPI Link
  const upiLink = `upi://pay?pa=${UPI_ID}&pn=${encodeURIComponent(PAYEE_NAME)}&am=${PRICE}&cu=INR&tn=${orderId}`;
  
  // Specific PhonePe Deep Link
  const phonePeLink = `phonepe://pay?pa=${UPI_ID}&pn=${encodeURIComponent(PAYEE_NAME)}&am=${PRICE}&cu=INR&tn=${orderId}`;

  // QR Code API
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(upiLink)}`;

  if (!isOpen) return null;

  // Simulate UTR validation
  const mockServerValidation = async (utrInput: string) => {
    return new Promise<{ success: boolean; message?: string }>((resolve) => {
      setTimeout(() => {
        // Validation Logic: Check if it is a 12-digit number (Standard UPI UTR)
        // Also allow the old demo keys for testing if needed
        const isValidFormat = /^\d{12}$/.test(utrInput);
        const isDemoKey = utrInput === 'MONEY2025' || utrInput === 'PROUSER';

        if (isValidFormat || isDemoKey) {
          resolve({ success: true });
        } else {
          resolve({ success: false, message: 'Invalid UTR Format. Please enter the 12-digit Ref Number.' });
        }
      }, 2000);
    });
  };

  const handleSubmit = async () => {
    if (!key.trim()) {
      setError("Please enter the UTR Number");
      return;
    }

    setIsValidating(true);
    setError('');
    
    try {
      const result = await mockServerValidation(key.trim());
      
      if (result.success) {
        localStorage.setItem('multiview_pro_key', key.trim());
        onUnlock();
        onClose();
        setKey('');
        setPaymentStep('pay'); // Reset for next time
        setShowPayment(false);
      } else {
        setError(result.message || 'Validation failed');
      }
    } catch (err) {
      setError('Connection failed. Please try again.');
    } finally {
      setIsValidating(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // Visual feedback handled by user interaction usually, keeping simple here
  };

  const handlePaidClick = () => {
    setPaymentStep('confirm');
  };

  const handleGoToInput = () => {
    setShowPayment(false);
    setPaymentStep('pay');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 relative max-h-[90vh] overflow-y-auto">
        
        {/* Close Button */}
        {!isValidating && (
          <button 
              onClick={onClose} 
              className="absolute top-4 right-4 z-20 text-white/80 hover:text-white transition-colors bg-black/10 hover:bg-black/20 rounded-full p-1"
          >
              <X size={20} />
          </button>
        )}

        {/* Header */}
        <div className="bg-gradient-to-br from-[#5f259f] to-[#4d1e82] p-6 text-white text-center relative overflow-hidden">
           {showPayment && (
             <button 
               onClick={() => {
                 if (paymentStep === 'confirm') setPaymentStep('pay');
                 else setShowPayment(false);
               }}
               className="absolute top-4 left-4 z-20 text-white/80 hover:text-white flex items-center gap-1 text-xs font-bold uppercase"
             >
               <ArrowLeft size={16} /> Back
             </button>
           )}
           
          <div className="bg-white/20 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3 backdrop-blur-md shadow-inner relative z-10">
             <Crown size={24} className="text-white fill-white" />
          </div>
          <h2 className="text-2xl font-bold relative z-10">
            {showPayment ? "Make Payment" : "Unlock Premium"}
          </h2>
          {showPayment && (
            <div className="flex items-center justify-center gap-1 text-purple-200 text-xs mt-1">
                <ShieldCheck size={12} />
                <span>Secure UPI Gateway</span>
            </div>
          )}
        </div>

        {/* --- VIEW 1: BENEFITS & ENTRY --- */}
        {!showPayment && (
          <div className="p-6 pt-4">
            <div className="space-y-2 mb-6">
              <FeatureRow text="Unlimited Screens (up to 40)" />
              <FeatureRow text="Ultra-Fast 1-Min Reloads" />
              <FeatureRow text="Exclusive Gold Theme" />
              <FeatureRow text="One-Time Payment - Lifetime" />
            </div>

            {/* PAYMENT BUTTON */}
            <div className="mb-6">
              <button 
                onClick={() => setShowPayment(true)}
                className="w-full bg-[#5f259f] hover:bg-[#4d1e82] text-white font-bold py-3 px-4 rounded-xl shadow-md transition-all active:scale-[0.98] flex items-center justify-center gap-3 group relative overflow-hidden"
              >
                <div className="flex flex-col items-start leading-none">
                  <span className="text-xs font-normal opacity-80">Pay ₹{PRICE} & Get Access</span>
                  <span className="text-lg">Pay via PhonePe / UPI</span>
                </div>
                <ArrowRight size={18} className="ml-auto opacity-70 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
              </button>
            </div>

            <div className="relative flex py-2 items-center mb-6">
              <div className="flex-grow border-t border-gray-200"></div>
              <span className="flex-shrink-0 mx-4 text-gray-400 text-xs font-bold uppercase tracking-widest">Activate</span>
              <div className="flex-grow border-t border-gray-200"></div>
            </div>

            {/* ACTIVATION INPUT (UTR) */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-500 uppercase ml-1">Enter UTR / Ref Number</label>
              <input 
                type="tel"
                maxLength={12} 
                value={key}
                disabled={isValidating}
                onChange={(e) => {
                    // Only allow numbers
                    const val = e.target.value.replace(/\D/g, '');
                    setKey(val);
                    setError('');
                }}
                onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
                placeholder="12-Digit UTR (e.g. 321456...)"
                className={`w-full p-3 bg-gray-50 border-2 rounded-xl focus:ring-4 focus:ring-purple-400/20 outline-none transition-all font-mono text-center text-lg tracking-widest
                    ${error ? 'border-red-300 focus:border-red-400' : 'border-gray-200 focus:border-purple-400'}
                `}
              />
              
              {error && (
                <div className="flex items-center gap-2 text-red-500 text-xs font-bold ml-1 animate-in slide-in-from-left-2">
                  <AlertCircle size={12} />
                  {error}
                </div>
              )}
              
              <button 
                  onClick={handleSubmit}
                  disabled={isValidating || key.length < 12}
                  className="w-full mt-2 bg-gray-900 hover:bg-black text-white font-bold py-3 rounded-xl shadow-lg transform transition-all active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                  {isValidating ? (
                    <>
                      <Loader2 size={18} className="animate-spin" />
                      Verifying UTR...
                    </>
                  ) : (
                    "Verify & Unlock"
                  )}
              </button>
            </div>
          </div>
        )}

        {/* --- VIEW 2: PHONEPE / UPI PAYMENT FLOW --- */}
        {showPayment && paymentStep === 'pay' && (
          <div className="p-6 pt-4 flex flex-col items-center">
            
            <div className="w-full animate-in fade-in slide-in-from-bottom-2 flex flex-col items-center">
                 {/* Order ID Banner */}
                <div className="w-full bg-purple-50 border border-purple-200 rounded-lg p-3 mb-4 flex items-start gap-3">
                  <div className="bg-purple-100 p-1 rounded-full text-purple-700 mt-0.5">
                      <Hash size={14} />
                  </div>
                  <div className="flex-1">
                      <p className="text-xs text-purple-800 font-bold uppercase">Order Reference</p>
                      <p className="text-sm text-gray-800 font-mono font-bold tracking-wider">{orderId}</p>
                  </div>
                </div>

                <div className="w-full bg-gray-50 rounded-xl p-4 border border-gray-200 mb-4 flex flex-col items-center">
                  <p className="text-gray-500 text-xs font-bold uppercase tracking-wider mb-3">Scan to Pay ₹{PRICE}</p>
                  <div className="w-40 h-40 bg-white p-2 rounded-lg shadow-inner border border-gray-200 flex items-center justify-center relative">
                    <img src={qrCodeUrl} alt="UPI QR" className="w-full h-full object-contain" />
                  </div>
                  <div className="flex items-center gap-2 mt-3 bg-white px-3 py-1.5 rounded border border-gray-200 w-full">
                    <p className="text-[10px] font-mono font-bold text-gray-600 truncate flex-1">{UPI_ID}</p>
                    <button onClick={() => copyToClipboard(UPI_ID)} className="text-blue-600 hover:bg-blue-50 p-1.5 rounded">
                        <Copy size={14} />
                    </button>
                  </div>
                </div>

                {/* Mobile Deep Links */}
                <div className="w-full grid grid-cols-2 gap-3 mb-4">
                  <a 
                    href={phonePeLink}
                    className="flex items-center justify-center gap-2 bg-[#5f259f] hover:bg-[#4d1e82] text-white py-3 rounded-lg font-bold text-sm shadow-md transition-transform active:scale-95"
                  >
                    <span>PhonePe</span>
                  </a>
                  <a 
                    href={upiLink}
                    className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-bold text-sm shadow-md transition-transform active:scale-95"
                  >
                     <span>Other UPI</span>
                  </a>
                </div>

                <div className="w-full border-t border-gray-200 my-2"></div>

                <button 
                  onClick={handlePaidClick}
                  className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-4 rounded-xl shadow-md transition-all active:scale-[0.98] flex items-center justify-center gap-2 animate-pulse"
                >
                  <Check size={20} />
                  I Have Completed Payment
                </button>
            </div>
          </div>
        )}

        {/* --- VIEW 3: CONFIRMATION INSTRUCTIONS --- */}
        {showPayment && paymentStep === 'confirm' && (
             <div className="p-6 pt-8 flex flex-col items-center text-center animate-in fade-in slide-in-from-right-4">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                    <Check size={32} className="text-green-600" strokeWidth={3} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Payment Recorded</h3>
                <p className="text-gray-600 text-sm mb-6">
                    Please find the <span className="font-bold text-black">12-Digit UTR Number</span> in your payment app (PhonePe/GPay) history.
                </p>

                <div className="bg-gray-100 p-4 rounded-xl w-full mb-6 text-left">
                    <p className="text-xs font-bold text-gray-500 uppercase mb-1">Example UTR Location:</p>
                    <div className="flex items-center justify-between bg-white p-2 rounded border border-gray-200">
                        <span className="text-xs text-gray-400">UPI Ref No:</span>
                        <span className="font-mono text-sm font-bold">321456789012</span>
                    </div>
                </div>

                <button 
                    onClick={handleGoToInput}
                    className="w-full bg-gray-900 hover:bg-black text-white font-bold py-3 px-4 rounded-xl shadow-lg flex items-center justify-center gap-2"
                >
                    Enter UTR to Unlock
                    <ArrowRight size={18} />
                </button>
             </div>
        )}

      </div>
    </div>
  );
};

const FeatureRow = ({ text }: { text: string }) => (
  <div className="flex items-center gap-3 text-gray-700">
    <div className="bg-green-100 text-green-600 p-1 rounded-full flex-shrink-0">
      <Check size={12} strokeWidth={3} />
    </div>
    <span className="font-medium text-xs md:text-sm">{text}</span>
  </div>
);

export default UnlockModal;