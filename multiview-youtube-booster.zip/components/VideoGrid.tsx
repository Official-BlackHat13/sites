import React, { useState } from 'react';
import { VolumeX, Volume2, Play, AlertTriangle, Loader2, RotateCcw, Crown } from 'lucide-react';

interface VideoGridProps {
  videoId: string | null;
  count: number;
  refreshKey: number;
  isMuted: boolean;
  isShort: boolean;
  isPro: boolean;
}

const VideoTile: React.FC<{ videoId: string; index: number; isMuted: boolean; isShort: boolean; isPro: boolean }> = ({ 
  videoId, 
  index, 
  isMuted,
  isShort,
  isPro
}) => {
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [retryCount, setRetryCount] = useState(0);

  const handleRetry = () => {
    setIsLoading(true);
    setHasError(false);
    setRetryCount((prev) => prev + 1);
  };

  return (
    <div className={`${isShort ? 'aspect-[9/16]' : 'aspect-video'} relative rounded-lg overflow-hidden shadow-lg bg-gray-900 group border transition-all duration-300 
      ${isPro ? 'border-yellow-500/40 shadow-yellow-500/10' : 'border-gray-800'}`}
    >
      
      {/* Pro Crown Indicator */}
      {isPro && !isLoading && !hasError && (
        <div className="absolute top-2 right-2 z-10 pointer-events-none animate-in fade-in zoom-in duration-700 delay-100">
           <div className="bg-black/50 backdrop-blur-md p-1.5 rounded-full border border-yellow-500/30 shadow-sm">
             <Crown size={12} className="text-yellow-400 fill-yellow-400" />
           </div>
        </div>
      )}

      {/* Error State */}
      {hasError && (
         <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-50 z-20 p-4 text-center">
             <div className="bg-red-100 p-3 rounded-full mb-3">
                <AlertTriangle size={24} className="text-red-500" />
             </div>
             <p className="text-gray-800 text-sm font-semibold mb-1">Video Unavailable</p>
             <p className="text-gray-500 text-xs mb-4">Connection interrupted</p>
             
             <button 
                onClick={handleRetry}
                className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 text-xs font-bold rounded-xl shadow-sm transition-all active:scale-95"
             >
                <RotateCcw size={14} />
                Try Again
             </button>
         </div>
      )}

      {/* Loading State */}
      {isLoading && !hasError && (
         <div className="absolute inset-0 flex items-center justify-center bg-gray-800 z-10">
             <Loader2 size={24} className="text-blue-400 animate-spin" />
         </div>
      )}

      {/* YouTube Iframe */}
      <iframe
        key={`${videoId}-${index}-${retryCount}`}
        src={`https://www.youtube.com/embed/${videoId}?autoplay=1&mute=${isMuted ? 1 : 0}&loop=1&playlist=${videoId}&controls=0`}
        title={`YouTube video player ${index}`}
        className={`w-full h-full object-cover transition-opacity duration-300 ${isLoading ? 'opacity-0' : 'opacity-100'}`}
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
        onLoad={() => setIsLoading(false)}
        onError={() => {
            setHasError(true);
            setIsLoading(false);
        }}
      />
      
      {/* Decorative Overlay (Only show if loaded and no error) */}
      {!isLoading && !hasError && (
        <>
            <div className="absolute top-2 left-2 z-10 pointer-events-none">
                <div className="bg-white/90 p-2 rounded-lg shadow-sm backdrop-blur-sm transition-all duration-300">
                    {isMuted ? (
                    <VolumeX size={20} className="text-red-500" />
                    ) : (
                    <Volume2 size={20} className="text-green-600" />
                    )}
                </div>
            </div>

            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="bg-white/20 p-4 rounded-full backdrop-blur-md">
                    <Play size={32} className="text-white fill-white" />
                </div>
            </div>
        </>
      )}
    </div>
  );
};

const VideoGrid: React.FC<VideoGridProps> = ({ videoId, count, refreshKey, isMuted, isShort, isPro }) => {
  if (!videoId) return null;

  // Create an array of size 'count'
  const screens = Array.from({ length: count }, (_, i) => i);

  // Dynamic Grid Calculation
  const getGridClasses = () => {
    // Base grid for mobile
    let classes = ""; 

    if (isShort) {
      // SHORTS (Vertical Video 9:16)
      // Can fit more columns because they are narrow
      if (count <= 10) {
        // Standard density for lower counts
        classes = "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4";
      } else {
        // High density for mass viewing (20, 30, 40)
        classes = "grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-3";
      }
    } else {
      // STANDARD (Horizontal Video 16:9)
      // Needs more width per tile
      if (count <= 10) {
         classes = "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4";
      } else {
         // Tighter packing for high volume
         classes = "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3";
      }
    }
    return classes;
  };

  return (
    <div className={`w-full mx-auto pb-20 p-4 ${getGridClasses()}`}>
      {screens.map((index) => (
        <VideoTile 
            key={`${videoId}-${index}-${refreshKey}-${isMuted ? 'muted' : 'unmuted'}`}
            videoId={videoId}
            index={index}
            isMuted={isMuted}
            isShort={isShort}
            isPro={isPro}
        />
      ))}
    </div>
  );
};

export default VideoGrid;