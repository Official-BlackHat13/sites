/**
 * Extracts the YouTube Video ID from various URL formats.
 * Returns an object containing the ID or a specific error message.
 */
export const getYouTubeID = (url: string): { id: string | null; error: string | null } => {
  if (!url || url.trim() === '') {
    return { id: null, error: "URL field cannot be empty." };
  }

  const trimmedUrl = url.trim();

  // Basic domain check
  if (!trimmedUrl.includes('youtube.com') && !trimmedUrl.includes('youtu.be')) {
    return { id: null, error: "URL does not match a known YouTube domain (youtube.com or youtu.be)." };
  }

  // Regular expression for standard YouTube links, embed links, and shortened links
  // Captures the ID in group 2
  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
  const match = trimmedUrl.match(regExp);

  if (match && match[2]) {
    const id = match[2];
    if (id.length === 11) {
      return { id, error: null };
    }
  }

  // Handle Shorts specifically if the regex above didn't catch it correctly or if it's a specific path
  if (trimmedUrl.includes('/shorts/')) {
    const parts = trimmedUrl.split('/shorts/');
    if (parts[1]) {
        // Remove query parameters and fragments
        const potentialId = parts[1].split(/[?#]/)[0]; 
        if (potentialId.length === 11) {
            return { id: potentialId, error: null };
        } else {
            return { id: null, error: "Invalid YouTube Shorts ID format. Expected 11 characters." };
        }
    }
  }

  // If regex matched something but it wasn't 11 chars, give a hint
  if (match && match[2].length > 0 && match[2].length !== 11) {
      return { id: null, error: `Extracted ID "${match[2]}" is invalid (length: ${match[2].length}, expected: 11).` };
  }

  return { id: null, error: "Could not parse Video ID from the provided URL." };
};

/**
 * Generates or retrieves a unique Device ID for this browser.
 * This mimics a "Physical Device" fingerprint.
 */
export const getDeviceId = (): string => {
  const STORAGE_KEY = 'multiview_device_id';
  let deviceId = localStorage.getItem(STORAGE_KEY);

  if (!deviceId) {
    // Generate a random unique string if one doesn't exist
    deviceId = 'dev_' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    localStorage.setItem(STORAGE_KEY, deviceId);
  }
  
  return deviceId;
};